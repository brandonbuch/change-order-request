function betterCountdown() {
    // sets the time for 10 seconds
    var currTime = 10;
    for (var i = 1; i <= 11; i++) {
        // if statement
        if (i == 11) {
            setTimeout(function () {
                // innerHTML ensures the HTML page is refreshed 
                document.getElementById("countdownTimer").innerHTML = "Blastoff";
            }, 1000 * i);
            // else if statement
        } else if (i > 6) {
            setTimeout(function () {
                // the halfway warning when it gets to <= 5 just a warning
                document.getElementById("countdownTimer").innerHTML =
                "Warning Less than half 1/2 way to launch, time left = " + currTime;
                currTime = currTime - 1;
            }, 1000 * i);
        } else {
            setTimeout(function () {
                // tells the time left when the timer gets to <= 5, goes hand and hand with the above function
                document.getElementById("countdownTimer").innerHTML = "the time left is " + currTime;
                currTime = currTime - 1;
            }, 1000 * i);

        }
    }
}
function whileCount() {
    // define variables
    var currtime = 10;
    var i = 1;
    while (i < 12) {
        // if statement
        if (i == 11) {
            setTimeout(function () {
                document.getElementById("countdownTimer").innerHTML = "Blastoff!:)";
            }, 1000 * i);
            // else if statement
        } else if (i > 6) {
            setTimeout(function () {
                document.getElementById("countdownTimer").innerHTML =
                    "Warning Less than half 1/2 way to launch, time left = " + currTime;
                currtime = currtime - 1;
            }, 1000 * i);
        } else {
            setTimeout(function () {
                document.getElementById("countdownTimer").innerHTML = "the time left is " + currtime;
                currtime = currtime - 1;
            }, 1000 * i);
        }
        i = i + 1;
    }
}   